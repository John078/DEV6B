from flask import *
from dbconnect import *

#cur = connection.cursor()

class Model:
	def Adjective(self):
		answer1 = "fdfs"
		self.givenAnswersAdj = [answer1.lower()]
		return self.givenAnswersAdj

	def GerundInfinitive1(self):
		answer1 = request.form['answer1']
		answer2 = request.form['answer2']
		answer3 = request.form['answer3']
		answer4 = request.form['answer4']
		answer5 = request.form['answer5']
		answer6 = request.form['answer6']
		answer7 = request.form['answer7']
		answer8 = request.form['answer8']
		answer9 = request.form['answer9']
		answer10 = request.form['answer10']
		self.givenAnswersG1 = [answer1.lower(), answer2.lower(), answer3.lower(), answer4.lower(), answer5.lower(), answer6.lower(), answer7.lower(), answer8.lower(), answer9.lower(), answer10.lower()]
		return self.givenAnswersG1

	def GerundInfinitive2(self):
		answer1 = "sdaflibfsd"
		self.givenAnswersG2 = [answer1.lower()]
		return self.given2AnswersG2

	def GerundInfinitive3(self):
		answer1 = "Hallokiasdfwcdsdoekie"
		self.givenAnswersG3 = [answer1.lower()]
		return self.given3AnswersG3

	def PresentPerfectContinuous1(self):
		answer1 = "SDafosudgfhekf"
		self.givenAnswerPPC1 = [answer1.lower()]
		return self.givenAnswerPPC1

	def PresentPerfectContinuous2(self):
		answer1 = "eilfhbs,fv"
		self.givenAnswerPPC2 = [answer1.lower()]
		return self.givenAnswerPPC2

	def Translate1(self):
		answer1 = "eilfsdfacsdac,fv"
		self.givenAnswerT1 = [answer1.lower()]
		return self.givenAnswerT1

	def Translate2(self):
		answer1 = "eilfhasdfcfdfv"
		self.givenAnswerT2 = [answer1.lower()]
		return self.givenAnswerT2

	def Translate3(self):
		answer1 = "sdfdfdcssac,fv"
		self.givenAnswerT3 = [answer1.lower()]
		return self.givenAnswerT3
 