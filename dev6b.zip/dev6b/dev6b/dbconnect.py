#import PyMySQL

#connection = PyMySQL.connect('localhost','dev016b_usr','2fnA2LPi','dev016b_db')
#connection.close()