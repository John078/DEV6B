from flask import Flask, render_template
from model import *

model = Model()

class Controller:
    def index():
        return render_template('Index.html')

    def ass1():
        if request.method == 'GET':
            return render_template('Assignment1.html')
        elif request.method == 'POST':
            givenAnswersG1 = model.GerundInfinitive1()
            return render_template("Result1.html", givenAnswersG1=givenAnswersG1)
